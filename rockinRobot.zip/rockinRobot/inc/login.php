<?php
    
    $hn = "localhost";
    $un = "root";
    $pw = "root";
    $dn = "products";


