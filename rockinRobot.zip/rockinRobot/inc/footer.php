<?php
$date = date("Y");


    
echo '<footer id="footer">&copy;' . $date. ' - Rockin Robots</footer>';

?>