<?php

echo '<head><link rel="stylesheet" href="../include/style.css"></head>

<nav>
<a class="header" href="index.php"><img style= "float:left; height:25%; width: 10%; padding:0 0 0 40px;" src="img/logo.png"><a href=shop.php></a>
<ul>
    <li><a class="header" href="shop.php">SHOP</a></li>
    <li><a class="header" href="#">CREATE</a></li>
    <li><a class="header" href="#">DISCOVER</a></li>
    <li><a class="header" href="#">LOCATION</a></li>
    <li><a class="header" href="#">SIGN IN</a></li>
    <li><a class="header" href="#">search</a></li>
    <li><a class="header" href="#">shopping cart</a></li>
</ul>
</nav>'
    
    ?>