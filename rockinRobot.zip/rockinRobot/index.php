<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rockin' Robots</title>
</head>

<style>
    <?php include 'inc/style.css'; ?>
</style>
    
<body>
<div class="hero">
    <h1>From high-flying drones to soccer-playing robots,<br> we have it all.</h1>
        <button><a id="button" href="shop.php">VIEW OUR COLLECTION</a></button>
</div>
</body>
 <?php
    include "inc/header.php"; 
    include "inc/footer.php";
?>

</html>